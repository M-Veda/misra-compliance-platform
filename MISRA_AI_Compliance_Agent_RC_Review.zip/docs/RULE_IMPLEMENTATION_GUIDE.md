# MISRA AI Compliance Agent — Rule Implementation Guide

> **Verification Scope**: Validated for the current implemented rule set and tested against the documented scenarios.

---

## 1. MISRA C:2012 Rule Classification & Status Matrix

| Rule | MISRA Title | Category | Severity | Detection Engine | Remediation Mode | Rationale / Transformation | Status |
| :---: | :--- | :--- | :---: | :--- | :---: | :--- | :---: |
| **2.2** | No dead code | Unused Code | Required | `rule_2_2.py` (AST unreachable visitor) | **Automated** | Line-erase unreachable code following `return`/`break`/`goto` | **Fully Functional** |
| **2.7** | Unused parameter | Unused Code | Advisory | `rule_2_7.py` (AST symbol table visitor) | **Automated** | Inserts `(void)param;` at body start | **Fully Functional** |
| **8.4** | Missing prototype | Declarations | Required | `rule_8_4.py` (AST FuncDef visitor) | **Automated** | Prepends forward declaration prototype | **Fully Functional** |
| **8.7** | Block scope | Declarations | Advisory | `rule_8_7.py` (AST FileScope visitor) | **Automated** | Prepends `static` keyword | **Fully Functional** |
| **9.1** | Uninit variable read | Initialization | Mandatory | `rule_9_1.py` (AST FlowVisitor) | **Manual Only** | Intentionally manual: Initializer value requires domain architectural knowledge | **Fully Functional (Manual Panel)** |
| **10.3**| Implicit narrowing | Types | Required | `rule_10_3.py` (AST EssentialTypeVisitor) | **Automated** | Inserts explicit cast `(target_type)expr` | **Fully Functional** |
| **12.1**| Operator precedence | Expressions | Advisory | `rule_12_1.py` (AST PrecedenceVisitor) | **Automated** | Inserts explicit operator precedence parentheses `a + (b * c)` | **Fully Functional** |
| **14.4**| Non-boolean condition | Control Flow | Required | `rule_14_4.py` (AST ConditionVisitor) | **Automated** | AST controlling expression rewriter (`if (count != 0)`) | **Fully Functional** |
| **15.5**| Single exit point | Control Flow | Required | `rule_15_5.py` (AST ExitVisitor) | **Manual Only** | Intentionally manual: Refactoring multiple `return` points requires function restructuring | **Fully Functional (Manual Panel)** |
| **17.7**| Return value unchecked | Input/Output | Required | `rule_17_7.py` (AST FuncCallVisitor) | **Manual Only** | Intentionally manual: Handling unchecked return values requires developer architectural intent review | **Fully Functional (Manual Panel)** |

---

## 2. Rationale for Manual-Only Rules

Rules **9.1, 15.5, and 17.7** are intentionally classified as **Manual-Only**:

1. **Rule 9.1 (Uninitialized Variable Read)**:
   - *Why Manual*: An uninitialized variable `int result;` read on a conditional branch cannot be safely auto-patched with a dummy fallback like `result = 0;` because setting an unverified fallback value may mask upstream logic bugs or violate safety assumptions in embedded code.
2. **Rule 15.5 (Single Exit Point)**:
   - *Why Manual*: Resolving early `return` statements requires refactoring control flow with local status variables and clean-up blocks, which alters control flow structure and requires developer sign-off.
3. **Rule 17.7 (Unchecked Return Value)**:
   - *Why Manual*: Ignoring function return values (e.g. `printf`, `scanf`, `memcpy`) requires human review to decide whether to check return status codes or explicitly suppress warnings using `(void)` cast based on safety intent.
