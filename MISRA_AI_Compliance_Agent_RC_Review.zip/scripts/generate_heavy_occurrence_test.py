import sys, os, pathlib
sys.path.insert(0, os.getcwd())

# Generate C file with 50+ occurrences of multiple rules
lines = [
    "/* heavy_multi_occurrence_test.c — 50+ occurrences per rule */",
    "#include <stdio.h>",
    ""
]

# 50 Rule 2.7 (Unused parameter) functions
for i in range(1, 51):
    lines.append(f"int func_unused_{i}(int a, int unused_{i}) {{")
    lines.append(f"    return a + {i};")
    lines.append("}")
    lines.append("")

# 50 Rule 12.1 (Operator precedence) statements inside a function
lines.append("int func_precedence(int x, int y, int z) {")
lines.append("    int res = 0;")
for i in range(1, 51):
    lines.append(f"    res += x + y * z + {i};  /* Rule 12.1 occurrence {i} */")
lines.append("    return res;")
lines.append("}")
lines.append("")

# 50 Rule 14.4 (Non-boolean condition) statements inside a function
lines.append("int func_conditions(int c) {")
lines.append("    int acc = 0;")
for i in range(1, 51):
    lines.append(f"    if (c + {i}) {{ acc += {i}; }}  /* Rule 14.4 occurrence {i} */")
lines.append("    return acc;")
lines.append("}")
lines.append("")

# 50 Rule 7.1 (Octal constants) statements inside a function
lines.append("int func_octal(void) {")
lines.append("    int sum = 0;")
for i in range(1, 51):
    lines.append(f"    sum += 077;  /* Rule 7.1 occurrence {i} */")
lines.append("    return sum;")
lines.append("}")
lines.append("")

# Write to file
dest = pathlib.Path("perf_test/heavy_multi_occurrence_test.c")
dest.write_text("\n".join(lines), encoding="utf-8")
print(f"Generated {dest} with {len(lines)} lines.")
