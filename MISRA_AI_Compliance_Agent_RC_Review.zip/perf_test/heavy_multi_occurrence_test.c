/* heavy_multi_occurrence_test.c — 50+ occurrences per rule */
#include <stdio.h>

int func_unused_1(int a, int unused_1) {
    return a + 1;
}

int func_unused_2(int a, int unused_2) {
    return a + 2;
}

int func_unused_3(int a, int unused_3) {
    return a + 3;
}

int func_unused_4(int a, int unused_4) {
    return a + 4;
}

int func_unused_5(int a, int unused_5) {
    return a + 5;
}

int func_unused_6(int a, int unused_6) {
    return a + 6;
}

int func_unused_7(int a, int unused_7) {
    return a + 7;
}

int func_unused_8(int a, int unused_8) {
    return a + 8;
}

int func_unused_9(int a, int unused_9) {
    return a + 9;
}

int func_unused_10(int a, int unused_10) {
    return a + 10;
}

int func_unused_11(int a, int unused_11) {
    return a + 11;
}

int func_unused_12(int a, int unused_12) {
    return a + 12;
}

int func_unused_13(int a, int unused_13) {
    return a + 13;
}

int func_unused_14(int a, int unused_14) {
    return a + 14;
}

int func_unused_15(int a, int unused_15) {
    return a + 15;
}

int func_unused_16(int a, int unused_16) {
    return a + 16;
}

int func_unused_17(int a, int unused_17) {
    return a + 17;
}

int func_unused_18(int a, int unused_18) {
    return a + 18;
}

int func_unused_19(int a, int unused_19) {
    return a + 19;
}

int func_unused_20(int a, int unused_20) {
    return a + 20;
}

int func_unused_21(int a, int unused_21) {
    return a + 21;
}

int func_unused_22(int a, int unused_22) {
    return a + 22;
}

int func_unused_23(int a, int unused_23) {
    return a + 23;
}

int func_unused_24(int a, int unused_24) {
    return a + 24;
}

int func_unused_25(int a, int unused_25) {
    return a + 25;
}

int func_unused_26(int a, int unused_26) {
    return a + 26;
}

int func_unused_27(int a, int unused_27) {
    return a + 27;
}

int func_unused_28(int a, int unused_28) {
    return a + 28;
}

int func_unused_29(int a, int unused_29) {
    return a + 29;
}

int func_unused_30(int a, int unused_30) {
    return a + 30;
}

int func_unused_31(int a, int unused_31) {
    return a + 31;
}

int func_unused_32(int a, int unused_32) {
    return a + 32;
}

int func_unused_33(int a, int unused_33) {
    return a + 33;
}

int func_unused_34(int a, int unused_34) {
    return a + 34;
}

int func_unused_35(int a, int unused_35) {
    return a + 35;
}

int func_unused_36(int a, int unused_36) {
    return a + 36;
}

int func_unused_37(int a, int unused_37) {
    return a + 37;
}

int func_unused_38(int a, int unused_38) {
    return a + 38;
}

int func_unused_39(int a, int unused_39) {
    return a + 39;
}

int func_unused_40(int a, int unused_40) {
    return a + 40;
}

int func_unused_41(int a, int unused_41) {
    return a + 41;
}

int func_unused_42(int a, int unused_42) {
    return a + 42;
}

int func_unused_43(int a, int unused_43) {
    return a + 43;
}

int func_unused_44(int a, int unused_44) {
    return a + 44;
}

int func_unused_45(int a, int unused_45) {
    return a + 45;
}

int func_unused_46(int a, int unused_46) {
    return a + 46;
}

int func_unused_47(int a, int unused_47) {
    return a + 47;
}

int func_unused_48(int a, int unused_48) {
    return a + 48;
}

int func_unused_49(int a, int unused_49) {
    return a + 49;
}

int func_unused_50(int a, int unused_50) {
    return a + 50;
}

int func_precedence(int x, int y, int z) {
    int res = 0;
    res += x + y * z + 1;  /* Rule 12.1 occurrence 1 */
    res += x + y * z + 2;  /* Rule 12.1 occurrence 2 */
    res += x + y * z + 3;  /* Rule 12.1 occurrence 3 */
    res += x + y * z + 4;  /* Rule 12.1 occurrence 4 */
    res += x + y * z + 5;  /* Rule 12.1 occurrence 5 */
    res += x + y * z + 6;  /* Rule 12.1 occurrence 6 */
    res += x + y * z + 7;  /* Rule 12.1 occurrence 7 */
    res += x + y * z + 8;  /* Rule 12.1 occurrence 8 */
    res += x + y * z + 9;  /* Rule 12.1 occurrence 9 */
    res += x + y * z + 10;  /* Rule 12.1 occurrence 10 */
    res += x + y * z + 11;  /* Rule 12.1 occurrence 11 */
    res += x + y * z + 12;  /* Rule 12.1 occurrence 12 */
    res += x + y * z + 13;  /* Rule 12.1 occurrence 13 */
    res += x + y * z + 14;  /* Rule 12.1 occurrence 14 */
    res += x + y * z + 15;  /* Rule 12.1 occurrence 15 */
    res += x + y * z + 16;  /* Rule 12.1 occurrence 16 */
    res += x + y * z + 17;  /* Rule 12.1 occurrence 17 */
    res += x + y * z + 18;  /* Rule 12.1 occurrence 18 */
    res += x + y * z + 19;  /* Rule 12.1 occurrence 19 */
    res += x + y * z + 20;  /* Rule 12.1 occurrence 20 */
    res += x + y * z + 21;  /* Rule 12.1 occurrence 21 */
    res += x + y * z + 22;  /* Rule 12.1 occurrence 22 */
    res += x + y * z + 23;  /* Rule 12.1 occurrence 23 */
    res += x + y * z + 24;  /* Rule 12.1 occurrence 24 */
    res += x + y * z + 25;  /* Rule 12.1 occurrence 25 */
    res += x + y * z + 26;  /* Rule 12.1 occurrence 26 */
    res += x + y * z + 27;  /* Rule 12.1 occurrence 27 */
    res += x + y * z + 28;  /* Rule 12.1 occurrence 28 */
    res += x + y * z + 29;  /* Rule 12.1 occurrence 29 */
    res += x + y * z + 30;  /* Rule 12.1 occurrence 30 */
    res += x + y * z + 31;  /* Rule 12.1 occurrence 31 */
    res += x + y * z + 32;  /* Rule 12.1 occurrence 32 */
    res += x + y * z + 33;  /* Rule 12.1 occurrence 33 */
    res += x + y * z + 34;  /* Rule 12.1 occurrence 34 */
    res += x + y * z + 35;  /* Rule 12.1 occurrence 35 */
    res += x + y * z + 36;  /* Rule 12.1 occurrence 36 */
    res += x + y * z + 37;  /* Rule 12.1 occurrence 37 */
    res += x + y * z + 38;  /* Rule 12.1 occurrence 38 */
    res += x + y * z + 39;  /* Rule 12.1 occurrence 39 */
    res += x + y * z + 40;  /* Rule 12.1 occurrence 40 */
    res += x + y * z + 41;  /* Rule 12.1 occurrence 41 */
    res += x + y * z + 42;  /* Rule 12.1 occurrence 42 */
    res += x + y * z + 43;  /* Rule 12.1 occurrence 43 */
    res += x + y * z + 44;  /* Rule 12.1 occurrence 44 */
    res += x + y * z + 45;  /* Rule 12.1 occurrence 45 */
    res += x + y * z + 46;  /* Rule 12.1 occurrence 46 */
    res += x + y * z + 47;  /* Rule 12.1 occurrence 47 */
    res += x + y * z + 48;  /* Rule 12.1 occurrence 48 */
    res += x + y * z + 49;  /* Rule 12.1 occurrence 49 */
    res += x + y * z + 50;  /* Rule 12.1 occurrence 50 */
    return res;
}

int func_conditions(int c) {
    int acc = 0;
    if (c + 1) { acc += 1; }  /* Rule 14.4 occurrence 1 */
    if (c + 2) { acc += 2; }  /* Rule 14.4 occurrence 2 */
    if (c + 3) { acc += 3; }  /* Rule 14.4 occurrence 3 */
    if (c + 4) { acc += 4; }  /* Rule 14.4 occurrence 4 */
    if (c + 5) { acc += 5; }  /* Rule 14.4 occurrence 5 */
    if (c + 6) { acc += 6; }  /* Rule 14.4 occurrence 6 */
    if (c + 7) { acc += 7; }  /* Rule 14.4 occurrence 7 */
    if (c + 8) { acc += 8; }  /* Rule 14.4 occurrence 8 */
    if (c + 9) { acc += 9; }  /* Rule 14.4 occurrence 9 */
    if (c + 10) { acc += 10; }  /* Rule 14.4 occurrence 10 */
    if (c + 11) { acc += 11; }  /* Rule 14.4 occurrence 11 */
    if (c + 12) { acc += 12; }  /* Rule 14.4 occurrence 12 */
    if (c + 13) { acc += 13; }  /* Rule 14.4 occurrence 13 */
    if (c + 14) { acc += 14; }  /* Rule 14.4 occurrence 14 */
    if (c + 15) { acc += 15; }  /* Rule 14.4 occurrence 15 */
    if (c + 16) { acc += 16; }  /* Rule 14.4 occurrence 16 */
    if (c + 17) { acc += 17; }  /* Rule 14.4 occurrence 17 */
    if (c + 18) { acc += 18; }  /* Rule 14.4 occurrence 18 */
    if (c + 19) { acc += 19; }  /* Rule 14.4 occurrence 19 */
    if (c + 20) { acc += 20; }  /* Rule 14.4 occurrence 20 */
    if (c + 21) { acc += 21; }  /* Rule 14.4 occurrence 21 */
    if (c + 22) { acc += 22; }  /* Rule 14.4 occurrence 22 */
    if (c + 23) { acc += 23; }  /* Rule 14.4 occurrence 23 */
    if (c + 24) { acc += 24; }  /* Rule 14.4 occurrence 24 */
    if (c + 25) { acc += 25; }  /* Rule 14.4 occurrence 25 */
    if (c + 26) { acc += 26; }  /* Rule 14.4 occurrence 26 */
    if (c + 27) { acc += 27; }  /* Rule 14.4 occurrence 27 */
    if (c + 28) { acc += 28; }  /* Rule 14.4 occurrence 28 */
    if (c + 29) { acc += 29; }  /* Rule 14.4 occurrence 29 */
    if (c + 30) { acc += 30; }  /* Rule 14.4 occurrence 30 */
    if (c + 31) { acc += 31; }  /* Rule 14.4 occurrence 31 */
    if (c + 32) { acc += 32; }  /* Rule 14.4 occurrence 32 */
    if (c + 33) { acc += 33; }  /* Rule 14.4 occurrence 33 */
    if (c + 34) { acc += 34; }  /* Rule 14.4 occurrence 34 */
    if (c + 35) { acc += 35; }  /* Rule 14.4 occurrence 35 */
    if (c + 36) { acc += 36; }  /* Rule 14.4 occurrence 36 */
    if (c + 37) { acc += 37; }  /* Rule 14.4 occurrence 37 */
    if (c + 38) { acc += 38; }  /* Rule 14.4 occurrence 38 */
    if (c + 39) { acc += 39; }  /* Rule 14.4 occurrence 39 */
    if (c + 40) { acc += 40; }  /* Rule 14.4 occurrence 40 */
    if (c + 41) { acc += 41; }  /* Rule 14.4 occurrence 41 */
    if (c + 42) { acc += 42; }  /* Rule 14.4 occurrence 42 */
    if (c + 43) { acc += 43; }  /* Rule 14.4 occurrence 43 */
    if (c + 44) { acc += 44; }  /* Rule 14.4 occurrence 44 */
    if (c + 45) { acc += 45; }  /* Rule 14.4 occurrence 45 */
    if (c + 46) { acc += 46; }  /* Rule 14.4 occurrence 46 */
    if (c + 47) { acc += 47; }  /* Rule 14.4 occurrence 47 */
    if (c + 48) { acc += 48; }  /* Rule 14.4 occurrence 48 */
    if (c + 49) { acc += 49; }  /* Rule 14.4 occurrence 49 */
    if (c + 50) { acc += 50; }  /* Rule 14.4 occurrence 50 */
    return acc;
}

int func_octal(void) {
    int sum = 0;
    sum += 077;  /* Rule 7.1 occurrence 1 */
    sum += 077;  /* Rule 7.1 occurrence 2 */
    sum += 077;  /* Rule 7.1 occurrence 3 */
    sum += 077;  /* Rule 7.1 occurrence 4 */
    sum += 077;  /* Rule 7.1 occurrence 5 */
    sum += 077;  /* Rule 7.1 occurrence 6 */
    sum += 077;  /* Rule 7.1 occurrence 7 */
    sum += 077;  /* Rule 7.1 occurrence 8 */
    sum += 077;  /* Rule 7.1 occurrence 9 */
    sum += 077;  /* Rule 7.1 occurrence 10 */
    sum += 077;  /* Rule 7.1 occurrence 11 */
    sum += 077;  /* Rule 7.1 occurrence 12 */
    sum += 077;  /* Rule 7.1 occurrence 13 */
    sum += 077;  /* Rule 7.1 occurrence 14 */
    sum += 077;  /* Rule 7.1 occurrence 15 */
    sum += 077;  /* Rule 7.1 occurrence 16 */
    sum += 077;  /* Rule 7.1 occurrence 17 */
    sum += 077;  /* Rule 7.1 occurrence 18 */
    sum += 077;  /* Rule 7.1 occurrence 19 */
    sum += 077;  /* Rule 7.1 occurrence 20 */
    sum += 077;  /* Rule 7.1 occurrence 21 */
    sum += 077;  /* Rule 7.1 occurrence 22 */
    sum += 077;  /* Rule 7.1 occurrence 23 */
    sum += 077;  /* Rule 7.1 occurrence 24 */
    sum += 077;  /* Rule 7.1 occurrence 25 */
    sum += 077;  /* Rule 7.1 occurrence 26 */
    sum += 077;  /* Rule 7.1 occurrence 27 */
    sum += 077;  /* Rule 7.1 occurrence 28 */
    sum += 077;  /* Rule 7.1 occurrence 29 */
    sum += 077;  /* Rule 7.1 occurrence 30 */
    sum += 077;  /* Rule 7.1 occurrence 31 */
    sum += 077;  /* Rule 7.1 occurrence 32 */
    sum += 077;  /* Rule 7.1 occurrence 33 */
    sum += 077;  /* Rule 7.1 occurrence 34 */
    sum += 077;  /* Rule 7.1 occurrence 35 */
    sum += 077;  /* Rule 7.1 occurrence 36 */
    sum += 077;  /* Rule 7.1 occurrence 37 */
    sum += 077;  /* Rule 7.1 occurrence 38 */
    sum += 077;  /* Rule 7.1 occurrence 39 */
    sum += 077;  /* Rule 7.1 occurrence 40 */
    sum += 077;  /* Rule 7.1 occurrence 41 */
    sum += 077;  /* Rule 7.1 occurrence 42 */
    sum += 077;  /* Rule 7.1 occurrence 43 */
    sum += 077;  /* Rule 7.1 occurrence 44 */
    sum += 077;  /* Rule 7.1 occurrence 45 */
    sum += 077;  /* Rule 7.1 occurrence 46 */
    sum += 077;  /* Rule 7.1 occurrence 47 */
    sum += 077;  /* Rule 7.1 occurrence 48 */
    sum += 077;  /* Rule 7.1 occurrence 49 */
    sum += 077;  /* Rule 7.1 occurrence 50 */
    return sum;
}
