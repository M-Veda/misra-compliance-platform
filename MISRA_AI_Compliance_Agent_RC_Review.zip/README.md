# MISRA AI Compliance Agent

> **Verification Scope & Wording**: Validated for the current implemented rule set and tested against the documented scenarios.  
> **Target Standard**: MISRA C:2012 (Automotive & Embedded Safety-Critical C Subset)

---

## Overview

The **MISRA AI Compliance Agent** is a static analysis and interactive remediation suite designed for embedded software engineers. It automates the detection, transactional patch application, and formal compliance report generation for MISRA C:2012 rules.

### Key Features
- **10 Core AST Rule Detectors**: Rules 2.2, 2.7, 8.4, 8.7, 9.1, 10.3, 12.1, 14.4, 15.5, 17.7.
- **Single-Source-of-Truth Working Copy**: Centralized state model in React (`AppContext.tsx`).
- **Transactional Bulk Accept Engine**: Priority-based spatial overlap resolution with bottom-up offset application and post-patch C AST syntax validation.
- **Strict Metric Invariants**: Counter equation $\text{Accepted} + \text{Rejected} + \text{Skipped} + \text{Manual} + \text{Remaining} = \text{Total Detected}$ holds strictly across all pages.
- **Informative Manual-Only Review**: Rules 9.1, 15.5, and 17.7 provide rule-specific, technically accurate manual remediation suggestions.
- **PDF Report Generation**: Professional ReportLab PDF export free of missing glyph (■) artifacts.

---

## Repository Structure

```
MISRA_Project/
├── backend/                    # FastAPI backend, pycparser AST detectors & patch engine
├── frontend/                   # React 18 SPA, Vite, TypeScript, Monaco Editor
├── perf_test/                  # Benchmark test C source files (small.c, medium.c, large.c)
├── docs/                       # Consolidated Documentation Suite (15 Markdown Files)
│   ├── API_DOCUMENTATION.md
│   ├── BACKEND_DOCUMENTATION.md
│   ├── CLEANUP_REPORT.md
│   ├── FEATURE_STATUS.md
│   ├── FILE_REFERENCE.md
│   ├── FINAL_PRODUCTION_VERIFICATION_REPORT.md
│   ├── FRONTEND_DOCUMENTATION.md
│   ├── LIMITATIONS_AND_FUTURE_WORK.md
│   ├── MODULE_REFERENCE.md
│   ├── PROJECT_HANDOVER.md
│   ├── PROJECT_OVERVIEW.md
│   ├── PROJECT_STRUCTURE.md
│   ├── RULE_IMPLEMENTATION_GUIDE.md
│   ├── SYSTEM_ARCHITECTURE.md
│   └── WORKFLOW_DOCUMENTATION.md

├── scripts/                    # Developer test & evidence collection utilities
│   ├── run_full_validation_suite.py
│   ├── generate_comprehensive_evidence.py
│   ├── benchmark_performance.py
│   ├── api_integration_test.py
│   └── generate_example_reports.py
├── LICENSE                     # MIT License
├── requirements.txt            # Python dependencies
├── .gitignore                  # Git ignore configuration
└── README.md                   # Project README
```

---

## Quick Start Guide

### 1. Start Backend Server
```bash
# Navigate to project root
cd c:\Users\saite\OneDrive\Desktop\MISRA_Project

# Install Python dependencies
pip install -r requirements.txt

# Launch FastAPI Uvicorn Server
python -m uvicorn backend.api.main:app --host 127.0.0.1 --port 8000 --reload
```

### 2. Start Frontend Application
```bash
# Navigate to frontend directory
cd c:\Users\saite\OneDrive\Desktop\MISRA_Project\frontend

# Install Node dependencies
npm install

# Start Vite Development Server
npm run dev
```
Open `http://localhost:5173/` in your browser.

---

## Verification & Testing

To run the automated E2E validation test suite:
```bash
python scripts/run_full_validation_suite.py
```

All 21 automated end-to-end test cases execute against the live API for the supported 10-rule scope.
